import React from 'react';
import Header from './Header';
import { Drawer } from '@mui/material';
//import DrawerComp from './DrawerComp';
import DrawerComp from './component/DrawerComp/DrawerComp';
import AvailableMeals from './component/invoice/AvailableMeals';
import Items from './component/items/Items';
function App() {
  return (
    <div>
      <Header />
      <DrawerComp/>
  
    
    </div>
  );
}

export default App;
