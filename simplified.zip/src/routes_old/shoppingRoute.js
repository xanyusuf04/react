import React from "react";
import NoRoute from "../components/pages/NoRoute";
import Category from "../components/pages/Category";
import Cart from "../components/Cart";
import Customer from "../component/dashboard/Dash";
import Dashboard from "../Dashboard";

const ShoppingRoutes = {
    path: "/",
    element: <Dashboard />,
    children: [
        {
            path: "/",
            element: <Category />,
        },
        {
            path: "cart",
            element: <Cart />,
        },
        {
            path: "customer",
            element: <Customer />,
        },
        {
            path: "*",
            element: <NoRoute />,
        },
   ],
};

export default ShoppingRoutes;