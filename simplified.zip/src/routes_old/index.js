import {useRoutes} from "react-router-dom";
import ShoppingRoutes from "./shoppingRoute";

const Routes = () => {
    return useRoutes ([ShoppingRoutes]);
};

export default Routes;


