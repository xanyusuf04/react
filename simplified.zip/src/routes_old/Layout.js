// import {Outlet, NavLink} from "react-router-dom";
// import { Box } from "@mui/material";
// import Dashboard from "../Dashboard";
// import Header from "../Header";

// const Layout = () => {
//     return (
//         <Box sx = {{ 
//             display: "flex", width: "100%"
//         }}>
//             <Box sx = {{
//                 display: "flex", flexDirection: "column", width: "100%"
//             }}>
//                 <Header />
//                 <Outlet />
//                 <Dashboard />
                
//             </Box>
//         </Box>
//     );
// };

// export default Layout;
