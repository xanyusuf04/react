import MealItemForm from "./MealsItemForm";


//this component majorly designed to have the meal items with price details
const MealItem = (props) => {
  const price = `$${props.price.toFixed(2)}`;
    
    // console.log(props.name);
    // console.log(props.description);

  return (
    <li>
      <div>
        <h3>{props.name}</h3>
        <div>{props.description}</div>
        <div>{price}</div>
      </div>
      <div>
        <MealItemForm id={props.id} />
      </div>
    </li>
  );
};

export default MealItem;