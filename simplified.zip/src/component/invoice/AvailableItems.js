//just for ex we used dummy data here: so no props used here as well
//transform this dummy data into the JSX element using map in the return
//Also need to wrap these meals data into container now
//import Invoice from "./Invoice";
import { useEffect, useState } from "react";
import ProductList from './ProductList';
import classes from "./AvailableItems.module.css";
//MealItem is passed here instead of list, it was a <li> earlier before MeatItem.js created
//id= {meal.id} added here to keep it unique id
const AvailableItems = () => {
  //Initially meals set to empty and state needed to rerender the component:
  const [meals, setMeals] = useState([]);
  //Updating LoadingState here and it is true initially as loaded the dummy data:
  const [isLoading, setisLoading] = useState(true);
  //To maintain error state:
  const [httpError, setHttpError] = useState();

  //using useEffect() to fetch the data since it fetches the data only when changes in it
  //if we use async in the useEffect() input then we should use await fetch()
  //FN passed into the useEffect() should not return a promise instead it may return only cleanup FN
  //Cleanup fn should run synchronously
  //useEffect( async () => { == >useEffect( () => {

  //Now this fn doesn't return a promise and still async can be used as const inside
  useEffect(() => {
    //it is a GET request, fetch returns a promise since sending a HTTP request is an asynchronous taskXXXX
    const fetchMeals = async () => {
      const response = await fetch(
        "https://react-307b7-default-rtdb.asia-southeast1.firebasedatabase.app/meals.json"
      );
      //.then(()=> {}); is called when fetch returns a promise, here NO promise called

      //we GET response here, so to find whethr any errors in response then add CODE HERE:
      if (!response.ok) {
        throw new Error("Something went wrong!");
      }

      const responseData = await response.json(); //here it is by default object but we need array

      //making it an array
      const loadedMeals = [];
      for (const key in responseData) {
        loadedMeals.push({
          //below names given in the firebase
          id: key,
          name: responseData[key].name,
          description: responseData[key].description,
          price: responseData[key].price,
        });
        //Response data to loadedMeals to State change
        setMeals(loadedMeals); //very important step to show the data
        console.log(loadedMeals);
        setisLoading(false); //as we are done with loading
      }
    };

    //Below try catch function will not return error since fetchMeals() is async FN in useEffect()
    //it always returns a promise, if we throw the error inside promise then that error will cause the promise to reject
    //we need to await the main fn which is not allowed here
    // try {
    //   fetchMeals();
    // } catch (error) {
    //   setisLoading(false);
    //   setHttpError(error.message);
    // }

    // fetchMeals(); -- this method catches the error inside the promise and works fine
    fetchMeals().catch((error) => {
      setisLoading(false);
      setHttpError(error.message);
    });
  }, []); //no dependency needed here

  //Loading is shown before returning the mealsItem so placed here:
  if (isLoading) {
    return (
      <section className={classes.MealsLoading}>
        <p>Loading...</p>
      </section>
    );
  }

  if (httpError) {
    return (
      <section className={classes.MealsError}>
        <p>{httpError}</p>
      </section>
    );
  }
  //HERE we need to rerender the component once fetching is done
  //after loaded for first time, we have initially no data and updating it when state changes
  //Preparing mealsList using state values
  const mealsList = meals.map((meal) => (
    <ProductList
      id={meal.id}
      key={meal.id}
      name={meal.name}
      description={meal.description}
      price={meal.price}
    />
  ));

  console.log(meals);

  return (
    <section className={classes.meals}>
      <ul>{mealsList}</ul>
    </section>
  );
};

export default AvailableItems;
