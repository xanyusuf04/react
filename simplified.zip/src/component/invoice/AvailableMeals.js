//just for ex we used dummy data here: so no props used here as well
//transform this dummy data into the JSX element using map in the return
//Also need to wrap these meals data into container now

import MealItem from "./MealsItem";

const DUMMY_MEALS = [
  {
    id: 'm1',
    name: 'Sushi',
    description: 'Finest fish and veggies',
    price: 22.99,
  },
  {
    id: 'm2',
    name: 'Schnitzel',
    description: 'A german specialty!',
    price: 16.5,
  },
  {
    id: 'm3',
    name: 'Barbecue Burger',
    description: 'American, raw, meaty',
    price: 12.99,
  },
  {
    id: 'm4',
    name: 'Green Bowl',
    description: 'Healthy...and green...',
    price: 18.99,
  },
];

//MealItem is passed here instead of list, it was a <li> earlier before MeatItem.js created
//id= {meal.id} added here to keep it unique id
const AvailableMeals = () => {
  const mealsList = DUMMY_MEALS.map((meal) => (
    <MealItem
    id= {meal.id}
      key={meal.id}
      name={meal.name}
      description={meal.description}
      price={meal.price}
    />
  ));

  return (
    <section >
            <ul>{mealsList}</ul>
      
    </section>
  );
};

export default AvailableMeals;