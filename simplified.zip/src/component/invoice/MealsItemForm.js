
//this is designed to show the amount and able to increase the items we need as input
//input designed separated to reuse when needed
//input and button make this component

//input={} contains a dummy object for the amount details:
const MealItemForm = (props) => {
  return (
    <form >
      
      <button>+ Add</button>
    </form>
  );
};

export default MealItemForm;