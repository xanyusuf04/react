import classes from '../customer/CustomerForm.module.css';
const ReportsForm = () => {
    return (
        <form className={classes.form} >



        <div className={classes.control}>
          <label htmlFor='name'>Customer Name *</label>
          <input type='text' id='name' />
         
        </div>
        <div className={classes.control}>
          <label htmlFor='invoicenumber'>Invoice# *</label>
          <input type='text' id='invoicenumber' />
         
        </div>
        <div className={classes.control}>
          <label htmlFor='ordernumber'>Order Number</label>
          <input type='text' id='ordernumber' />
        </div>
        <div className={classes.control}>
          <label htmlFor='invoicedate'>Invoice Date *</label>
          <input type='text' id='invoicedate'  />
        </div>
        <div className={classes.control}>
          <label htmlFor='terms'>Terms</label>
          <div className= {classes.control} >

  <select>
    <option value="0">Select Terms:</option>
    <option value="1">Due on Receipt</option>
    <option value="2">Due end of month</option>
    <option value="3">Due end of next month</option>
    <option value="4">Custom</option>
  </select>
</div>
        </div>
        <div className={classes.control}>
          <label htmlFor='duedate'>Due Date</label>
          <input type='text' id='duedate'  />
        </div>
        <div className={classes.control}>
          <label htmlFor='subject'>Subject</label>
          <input type='text' id='subject'  />
        </div>
        <div className={classes.actions}>
          <label htmlFor='itemdetails'>ITEM DETAILS</label>
          <label htmlFor='quantity'>QUANTITY</label>
          <label htmlFor='rate'>RATE</label>
          <label htmlFor='amount'>AMOUNT</label>
          </div>
          <div className={classes.actions}>
          <input type='text' id='itemdetails'  />
          <input type='text' id='quantity'  />
          <input type='text' id='rate'  />
          <input type='text' id='amount'  />
        </div>
        <button className={classes.submit}>+Add</button>
        <div className={classes.control}>
          <label htmlFor='cutomernotes'>CUSTOMER NOTES</label>
          <input type='text' id='cutomernotes'  />
        </div>

        <div className={classes.control}>
          <label htmlFor='discount'>DISCOUNT %</label>
          <input type='text' id='discount'  />
        </div>
        
        <div className={classes.control}>
          
          <label htmlFor='deductionname'>DEDUCTION NAME </label>
          <select>
    <option value="0">Select Type:</option>
    <option value="1">Brokerage</option>
    <option value="2">Commission of 5%</option>
    <option value="3">Commission of 4%</option>
    <option value="4">Commission of 10%</option>
  </select>
  <label htmlFor='deductionpercent'>OTHER DEDUCTIONS % (if any):</label>
          <input type='text' id='deductionpercent'  />
        </div>

        <div className={classes.actions}>
          <label htmlFor='roundoff'>Round off</label>
          <input type='text' id='roundoff'  />
        </div>
        <div className={classes.control}>
          <label htmlFor='total'>TOTAL (Rupee) </label>
          <input type='text' id='total'  />
        </div>
        <div className={classes.control}>
          <label htmlFor='termsconditions'>Terms & Conditions</label>
          <input type='text' id='termsconditions'  />
                 </div>

        <div className={classes.actions}>
          <button type='button' >
            Cancel
          </button>
          <button className={classes.submit}>Save as Draft</button>
          <button className={classes.submit}>Save and Send</button>
        </div>
      </form>
    );
};

export default ReportsForm;