//Going with useReducer since it has a complex states management
//Becoz Need to check meal is part of the cart or not already and it is difficult state to maintain
import { useReducer } from 'react';

import CartContext from './cart-context';


//like not item or empty array to return as default
const defaultCartState = {
  items: [],
  totalAmount: 0
};

//cartReducer wont need any data from component so defined outside and that's the practise 
//and should NOT be recrated when component is executed

//State object is received and action is dispatched
//state - last state snapshot of the state managed by the reducer
//action - automaticaly by react, action is dispatched by you or your code
//part of the reducer function you need to return the new state snapshot
// const cartReducer = (state, action) => {
// //Now here we define what this action "ADD" has to do when invoked
//   if (action.type === 'ADD') {
//     const updatedItems = state.items.concat(action.item); //items in the current snapshot
//     //need immutable array, so concat is called (adds a new item to an array, but returns a new array..
//     //kind of important since push returns only the updated existing array)
//     const updatedTotalAmount = state.totalAmount + action.item.price * action.item.amount;
//     return {
//       items: updatedItems,
//       totalAmount: updatedTotalAmount
//     };
//   }
//   return defaultCartState;
// };


////below code added at a stretch to avoid confusion:
////////////////////////////////////////////////////////////
const cartReducer = (state, action) => {
    if (action.type === 'ADD') {
      const updatedTotalAmount =
        state.totalAmount + action.item.price * action.item.amount;
  
      const existingCartItemIndex = state.items.findIndex(
        (item) => item.id === action.item.id
      );
      const existingCartItem = state.items[existingCartItemIndex];
      let updatedItems;
  
      if (existingCartItem) {
        const updatedItem = {
          ...existingCartItem,
          amount: existingCartItem.amount + action.item.amount,
        };
        updatedItems = [...state.items];
        updatedItems[existingCartItemIndex] = updatedItem;
      } else {
        updatedItems = state.items.concat(action.item);
      }
  
      return {
        items: updatedItems,
        totalAmount: updatedTotalAmount,
      };
    }
    if (action.type === 'REMOVE') {
      const existingCartItemIndex = state.items.findIndex(
        (item) => item.id === action.id
      );
      const existingItem = state.items[existingCartItemIndex];
      const updatedTotalAmount = state.totalAmount - existingItem.price;
      let updatedItems;
      if (existingItem.amount === 1) {
        updatedItems = state.items.filter(item => item.id !== action.id);
      } else {
        const updatedItem = { ...existingItem, amount: existingItem.amount - 1 };
        updatedItems = [...state.items];
        updatedItems[existingCartItemIndex] = updatedItem;
      }
  
      return {
        items: updatedItems,
        totalAmount: updatedTotalAmount
      };
    }
  
    return defaultCartState;
  };

  
  //////////////////////////////////////////////////////


//Goal is component is to manage the context data and simply to provide to other comps when required
//addItemToCartHandler and removeItemFromCartHandler are like login and logout handlers
const CartProvider = (props) => {
//useReducer returns an array with exactly two elements
//Hence using array destructuring to pull those elements and storing in the const
//First element is always a state snapshot (cartState)
//Second element function which allows you to dispatch an action
  const [cartState, dispatchCartAction] = useReducer(cartReducer, defaultCartState);


  //Dispatching actions are defined below for the useReducers:
  //Use some property to identity the action, here type is used (which is user defined name, readable one)
  //it could also be "ADD_ITEM" or "REMOVE_ITEM"
  const addItemToCartHandler = (item) => {
    dispatchCartAction({type: 'ADD', item: item});
  };
  const removeItemFromCartHandler = (id) => {
    dispatchCartAction({type: 'REMOVE', id: id});
  };

  const cartContext = {
    items: cartState.items,
    totalAmount: cartState.totalAmount,
    addItem: addItemToCartHandler,
    removeItem: removeItemFromCartHandler,
  };

  //CartContext.Provider is a provider here like App to other component:
  return (
    <CartContext.Provider value={cartContext}>
      {props.children}
    </CartContext.Provider>
  );
};

export default CartProvider;