//store folder side by side to the components and assets folder, need to store app-wise state mgmt
//this name "store" widely used in react world

//Here card-context is used to add data/ items
//Context lets components pass information deep down without explicitly passing props
//No component created here
//initialize with dummy data: two fns to update the context -- addItem and removeItem
//it mainly has item and amount data only
import React from 'react';
const CartContext = React.createContext({
  items: [],
  totalAmount: 0,
  addItem: (item) => {},
  removeItem: (id) => {}
});

export default CartContext;

//Need to manage the context over time and we could see this in same file but we create a new file called
//CartProvider.js which receives the props

