import React, {useState} from 'react';
import classes from '../customer/CustomerForm.module.css';


const ItemsForm = (props) => {

  const [trackStock, setTrackStock] = useState(false);

  const trackStockHandler = () =>
  {
    setTrackStock(!trackStock);
    console.log(trackStock);

  }

  
      return (
        <form className={classes.form} >



        <div className={classes.control}>
          <label htmlFor='name'>Product Name *</label>
          <input type='text' id='name' />
         
        </div>
        <div className={classes.control}>
          <label htmlFor='code'>Product code# *</label>
          <input type='text' id='code' />
         
        </div>
        <div className={classes.control}>
          <label htmlFor='category'>Category</label>
          <div className= {classes.control} >
              <select>
                <option value="0">Select Terms:</option>
                <option value="1">No Category</option>
                <option value="2">Custom</option>
              </select>
        </div>
        </div>
        <div className={classes.control}>
          <label htmlFor='barcode'>Bar code if any:</label>
          <input type='text' id='barcode' />
        </div>
       
        <div className={classes.control}>
          <label htmlFor='soldby'>Sold By</label>
          <div className= {classes.control} >
  <select>
    <option value="0">Select the unit:</option>
    <option value="1">Each</option>
    <option value="2">Kg</option>
    <option value="3">l</option>
    <option value="4">m</option>
    <option value="5">g</option>
    <option value="6">lb</option>
  </select>
</div>
        </div>
        <div className={classes.control}>
          <label htmlFor='sp'>Selling Price in Rupee:</label>
          <input type='number' id='sp'  />
        </div>
        <div className={classes.control}>
          <label htmlFor='cp'>Cost Price in Rupee:</label>
          <input type='number' id='cp'  />
        </div>
        
        <div className={classes.control}>
          <label htmlFor='cutomernotes'>CUSTOMER NOTES</label>
          <input type='text' id='cutomernotes'  />
        </div>

        <div className={classes.control}>
          <label htmlFor='discount'>DISCOUNT % if any:</label>
          <input type='number' id='discount'  />
        </div>
        
        <div className={classes.control}>
          <label htmlFor='trackstock'>Do you want to track the stocks..? </label>
          <input type='checkbox' id='trackstock'  onClick={trackStockHandler} />
        </div>
        { trackStock &&
        <div className={classes.control}>
          <label htmlFor='availablestock'>Available Stock..? </label>
          <input type='number' id='availablestock'  />
        </div>
}
        <div className={classes.actions}>
          <button type='button' onClick = {props.onCancel}>
            Cancel
          </button>
          <button className={classes.submit} >Save as Draft</button>
          <button className={classes.submit}>Save and Send</button>
        </div>
      </form>
    );
};

export default ItemsForm;